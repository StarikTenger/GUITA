var tex_ = "resources/textures";
var snk_ = tex_ + "snake";

var FRAME_CNT_SNAKE = 16;
var FRAME_CNT_STATIC = 1;

var EXT_PNG = "png";


// let AH_snake_head_enter = new AnimationHolder(
//     tex_ + "/snake/head/enter",
//     EXT_PNG,
//     FRAME_CNT_SNAKE
// )
